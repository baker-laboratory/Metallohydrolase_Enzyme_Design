RFdiffusion3 metalloprotease computational design models

Each PDB is the archived model selected for the corresponding ordered
design. Chain A is the protease design and chain B is the 10-residue
substrate epitope. The models describe the protease–peptide complex.
The assay linkers, fluorescent reporter, and affinity tag are described
in the sequence workbook.

The TTR folder contains the 96 computational complexes corresponding
to the transthyretin design campaign reported in Science.
Match model_file and design_id to all_designs in the sequence workbook.
model_index.tsv gives the SHA-256 digest of each original PDB.
