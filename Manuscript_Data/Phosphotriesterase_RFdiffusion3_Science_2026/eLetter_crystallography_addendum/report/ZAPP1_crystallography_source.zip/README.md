# ZAPP-1 crystallography report: LaTeX source

Upload this ZIP to Overleaf, set `main.tex` as the main document, and compile
with pdfLaTeX and BibTeX. The source includes the two figure PDFs and the
bibliography used for the report.
